Python3.11虚拟环境中安装：

```bash
pip install torch==2.5.1 --index-url https://download.pytorch.org/whl/cpu
pip install robosuite==1.4.0 mujoco==2.3.7 numpy==1.26.4 Pillow==11.3.0 bddl==1.0.1 future==1.0.0 matplotlib==3.8.4 cloudpickle==3.1.1 gym==0.25.2 easydict==1.13 pyyaml==6.0.2 opencv-python-headless==4.10.0.84 termcolor==2.4.0 requests==2.32.5
git clone https://github.com/Lifelong-Robot-Learning/LIBERO.git
cd LIBERO
git checkout 8f1084e3132a39270c3a13ebe37270a43ece2a01
pip install --no-deps -e .
cd ..
```

保留完整克隆目录中的assets/bddl_files/init_files。首次导入按提示建立LIBERO路径配置，演示数据并非运行环境必须项。Linux软件渲染需安装libosmesa6并设置MUJOCO_GL=osmesa、PYOPENGL_PLATFORM=osmesa。也可直接在解压目录构建Dockerfile.environment，它已包含资源和路径配置。
