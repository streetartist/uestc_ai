开发包包含接口示例agent.py和纯CPU最近邻模仿学习基线：

1. 按LIBERO官方数据说明取得三个已公布任务的公开演示HDF5，可遍历公开初态、收集轨迹并训练或调试策略。最终评测采用独立场景。
2. 训练侧安装h5py，运行 `python train_policy.py --demo task_demo.hdf5 --output task-policy.npz`。每任务单独训练，默认最多2048样本。
3. 将nearest_neighbor_agent.py改名为agent.py；config.json的policy_files将三个task_name分别映射到对应NPZ。
4. 将agent.py、config.json、policy_features.py和三个NPZ打包，运行practice.py，再按20MB限制上传。

可改为BC网络、策略模型或自定义harness，也可复用固定脚本技能。verification、记忆和规划均使用题面规定的画面、机器人状态与执行历史；物体真值、接触状态和原生成功标志仅供评测器使用。训练与测试动作均为原生七维动作，图像上下方向须一致。
