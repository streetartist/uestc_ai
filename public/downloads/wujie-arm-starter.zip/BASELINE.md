接口示例agent.py可立即练习，不代表任务求解。另提供纯CPU最近邻模仿学习基线：

1. 按LIBERO官方数据说明取得三个已公布任务的公开演示HDF5，不使用测试初始状态生成训练数据。
2. 训练侧安装h5py，运行 `python train_policy.py --demo task_demo.hdf5 --output task-policy.npz`。每任务单独训练，默认最多2048样本。
3. 将nearest_neighbor_agent.py改名为agent.py；config.json的policy_files将三个task_name分别映射到对应NPZ。
4. 将agent.py、config.json、policy_features.py和三个NPZ打包，运行practice.py，再按20MB限制上传。

该基线仅是可优化的轻量策略入口，未提供预训练权重和成功率承诺。可改为BC网络、策略模型或自定义harness。训练与测试动作均为原生七维动作，图像上下方向须一致。
