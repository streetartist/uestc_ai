## 任务背景与目标

人体行为识别是智能家居、健康监测与人机交互中的重要技术。本赛题使用 CUHK-X 人体活动数据中的深度图像等非RGB数据，训练能够识别 **40类日常动作** 的分类模型，引导学生完成数据处理、特征提取、模型训练与效果验证。

参赛者可以研究视频时序信息、模型结构、数据增强和轻量化设计，在识别准确率、计算量与处理速度之间取得平衡。禁止使用RGB图像或测试集标签开展训练、调参或人工修正预测。

## 数据与开发环境

本届推理协议限定**深度图像单模态**，输出40类日常动作。RGB数据、RGB预训练特征和测试标签不能用于训练、调参或人工修正预测。训练数据、40类有序映射、预处理和跨被试划分须随数据版本一起发布；同一被试不能跨训练和正式测试集，同一原始片段的派生样本不能跨集合。

数据来源：[CUHK-X 官方项目](https://github.com/openaiotlab/CUHK-X)及[官方挑战赛](https://openaiotlab.github.io/CUHK-X-Challenge/)。组织方已确认取得覆盖本届参赛队伍的数据分发授权，使用官方带标签数据按被试重新划分：训练1,995段、验证466段、测试470段，各集合均覆盖40类。数据源标签公开，本届结合评委代码审查，不宣称严格独立盲测。原赛事成绩、样例数据结果不得替代本届统一测评。

本届统一训练镜像内置训练集、验证集和类别映射，不需要重新下载44.6GB多模态原始压缩包。数据路径为 `/opt/uestc-classification/training-data/train` 和 `/opt/uestc-classification/training-data/validation`。队伍可使用题目资源面板提供的RTX4080SUPER32GB渠道，每队本题10GPU卡时、参考运行费用上限16.8元；实际可用余量以资源面板为准。也可在获得相应数据授权后自行配置训练环境。

输入为官方伪彩色深度图，按帧序号排序后均匀取16帧，经Pillow亮度转换和双线性缩放至112×112，输出float32 `[16,1,112,112]` NPY，范围[0,1]，不代表物理深度距离。类别顺序位于 `/opt/uestc-classification/depth-class-mapping.csv`，并与各集合的 `manifest.json` 一致。训练、验证、测试按12/3/3被试隔离，跨集合重复检查已通过。

## 提交材料

1. 训练与推理代码 ZIP：包含依赖、预处理流程、训练入口、推理入口及运行配置；不得包含测试标签、账号密钥或原始授权数据。
2. 模型权重：小权重可随ZIP提供；大权重在 `config.json` 中声明固定HTTPS地址、大小和 SHA-256，避免单附件20MB限制。下载域名须经组织方批准，地址保持有效至评测结束。
3. 预测结果 CSV：按公布的样本ID和类别映射提交，不得漏行、重复ID或包含非法类别。
4. README 技术路线说明：输入处理、模型设计、训练设置、效果与复现命令；PDF、研究发现和消融实验可选。
5. README 与运行说明：软硬件版本、依赖安装、随机种子、训练/推理命令、权重校验和、预测文件结构及复现步骤。

推理包根目录包含 `inference.py` 和 `config.json`。实现 `Model(config, device)`，其中 `predict(sample_path)` 返回40类分数。组织方使用与训练镜像相同的 `[T,1,H,W]` 非RGB NPY预处理。公开验证集预测CSV采用 `sample_id,predicted_class` 两列，sample_id取验证集manifest中的file值，predicted_class为类别索引0～39。

[下载推理开发示例](/downloads/wujie-classification-starter.zip?v=wujie-v3)：包含轻量3D-CNN、训练/推理入口、批量预测与配置，不附带已训练权重。

## 评测与评审

可信推理在组织方独立 AutoDL RTX 4080 系列实例运行，不使用选手拥有 root 权限的训练实例。固定Python3.12.3、PyTorch2.8.0+cu128、torchvision0.23.0+cu128、NumPy2.3.2、Pillow10.4.0、safetensors0.5.3。训练镜像与测评镜像使用同一环境；模型须兼容，不在测评时安装依赖。

`predict(sample_path)` 返回40个有限分数，类别顺序固定；单条输入为数值 NPY `[T,1,H,W]`，不使用 pickle。模型初始化不计入单样本延迟，但计入整次时限；首条预测参与准确率、作为延迟预热，后续计时包含读取、预处理、预测和CUDA同步。样本随机命名逐条提供，不给模型测试标签或原始身份。模型参数量、FLOPs和权重大小在报告中提供可复现计算；GPU显存由外部采样记录，属于采样峰值而非精确分配峰值。

每队 **3 次自测**，每次 **1800秒总时限**，4CPU、6144MiB主机内存、一张独占4080系列GPU；单ZIP20MB、解压64MB。训练权重随ZIP提供或按声明的HTTPS地址与SHA-256下载。组织方隐藏数据和判分程序不向模型开放。模型读取标签、伪造指标、非法网络访问、超时、NaN输出均无法得到有效测评结果。

先上传推理ZIP发起测试，完成后选择一条结果并用相同ZIP正式提交，补齐训练代码、验证集预测CSV、技术路线说明与README。**CSV为公开验证集结果，不要求提交含隐藏测试标签的预测文件**；比赛分数由组织方运行模型得到。正式提交不另扣一次测试；超时和代码异常计次，平台故障由组织方核查处理。

准确率 `A` 和40类 Macro F1 `F` 使用0–100尺度，类别缺少正确预测时该类别F1为0。平均推理延迟 `L` 以毫秒计算，效率系数 `E=min(1,100/max(L,0.001))`。

**自动表现分 = 0.80×A＋0.10×F＋0.10×A×E**，公式版本 `wujie-depth-v1`。速度部分与准确率挂钩，空模型即使很快也不能获得效率分。硬件与数据版本在首个正式测试前固定，所有队伍一致。

## 自测开放条件

开发包、数据镜像、40类映射和预处理已经固定。自测按赛事公布的开赛与截止时间开放；平台收到测试后自动启动组织方专用GPU测评机，依次运行排队任务，空闲后自动关机。等待开机不占1800秒推理时限。开机失败或推理前的程序包传输故障会退回测试机会；选手程序错误与运行超时计入次数。开发样例、弱基线验收和合成数据的指标不计入参赛成绩。


# 无界杯：选手训练镜像（内置数据）

镜像内置本届固定版本的训练集1,995段、验证集466段，两组均覆盖40类。无需再次下载或解压44.6GB原始多模态数据。训练数据位于系统镜像内，创建实例后直接使用。

解释器：`/opt/uestc-classification/runtime/bin/python`。环境为Python3.12.3、PyTorch2.8.0+cu128、torchvision0.23.0+cu128、NumPy2.3.2、Pillow10.4.0、safetensors0.5.3。

## 开始训练

```bash
/opt/uestc-classification/runtime/bin/python \
  /opt/uestc-classification/starter/train.py \
  --training-data /opt/uestc-classification/training-data/train \
  --validation-data /opt/uestc-classification/training-data/validation \
  --epochs 10 --batch-size 8 --output /root/autodl-tmp/model.safetensors

/opt/uestc-classification/runtime/bin/python \
  /opt/uestc-classification/backend/build_classification_package.py \
  --weights /root/autodl-tmp/model.safetensors \
  --output /root/autodl-tmp/submission.zip
```

训练时逐轮显示耗时、损失和验证准确率。示例是轻量基线，选手可替换模型。`submission.zip`包含推理代码、配置和权重；训练代码与README技术路线按题目要求提交，研究PDF可选。

批量预测请下载最新开发包，在包含config.json、inference.py、network.py、predict.py与model.safetensors的目录运行：

```bash
/opt/uestc-classification/runtime/bin/python predict.py \
  --dataset /opt/uestc-classification/training-data/validation \
  --output predictions.csv
```

生成CSV两列 `sample_id,predicted_class`，类别编号0–39。predict.py在最新开发包中提供；已保存的v4镜像不需要重建或重新下载数据。

## 数据与预测接口

数据来自[CUHK-X官方仓库](https://huggingface.co/datasets/Kevin-Pal/CUHK-X_Small_Model_Track)，组织方已确认取得覆盖本届参赛队伍的数据分发授权，仅供本届授权参赛用途。请遵守数据授权并在报告中注明来源。

使用非RGB的伪彩色深度图，按帧序号排序后均匀取16帧，经Pillow亮度转换和112×112缩放，输出float32 `[16,1,112,112]` NPY，范围[0,1]，不代表物理距离。类别索引遵循 `/opt/uestc-classification/depth-class-mapping.csv`；训练、验证与测试被试互不重叠。

`Model(config, device).predict(sample_path)`必须返回40个有限数值。不得使用RGB、读取测试标签或自行填报比赛分数。组织方统一运行推理并生成指标；本届采用官方公开带标签数据重新划分，结合评委代码检查，不宣称严格独立盲测。

本镜像不包含组织方测试数据、测试标签、训练好的权重或平台/API密钥。不要向队伍挂载组织方共享文件存储；同一AutoDL账号的共享盘不能靠root权限隔离各队。
